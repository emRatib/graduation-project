<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('name');
            $table->bigInteger('email');
            $table->bigInteger('password');
            $table->bigInteger('createdAt');
            $table->bigInteger('updatedAt');
            $table->bigInteger('deletedAt');
            $table->bigInteger('verifiedAt')->nullable();
            $table->bigInteger('verified')->nullable();
            $table->bigInteger('rememberToken')->nullable();
            $table->bigInteger('image_path')->nullable()->default('profile.png');
            $table->bigInteger('status')->default('active');
            $table->bigInteger('phone')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
